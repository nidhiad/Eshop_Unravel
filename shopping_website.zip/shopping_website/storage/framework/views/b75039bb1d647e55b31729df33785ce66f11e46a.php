<?php $__env->startSection('content'); ?>

<section id="form" style="margin-top:20px;"><!--form-->
	<div class="container">
		<div class="row">

			<div class="col-sm-4 col-sm-offset-1">
				<div class="login-form"><!--login form-->
					<h2>Login to your account</h2>
					<form id="loginForm" name="loginForm" action="<?php echo e(url('/user-login')); ?>" method="POST"><?php echo e(csrf_field()); ?>

						<input name="email" type="email" placeholder="Email Address" required="" />
						<input name="password" type="password" placeholder="Password" required="" />
						<!-- <span>
							<input type="checkbox" class="checkbox">
							Keep me signed in
						</span> -->
						<button type="submit" class="btn btn-default">Login</button><br>
						<a href="<?php echo e(url('forgot-password')); ?>">Forgot Password?</a>
					</form>
				</div><!--/login form-->
			</div>
		</div>
	</div>
</section><!--/form-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontLayout.front_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopping_website\resources\views/users/login_register.blade.php ENDPATH**/ ?>