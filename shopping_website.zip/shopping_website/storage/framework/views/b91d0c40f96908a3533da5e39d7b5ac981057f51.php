<?php $__env->startSection('content'); ?>
@<style media="screen">
.product-quantity {
		padding: 5px 10px;
		border-radius: 3px;
		border: #E0E0E0 1px solid;
}
</style>

</css>
<section id="slider"><!--slider-->
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<table class="tbl-cart" cellpadding="10" cellspacing="1">
					<tbody>
					<tr>
					<th style="text-align:left;">Name</th>
					<th style="text-align:left;">Code</th>
					<th style="text-align:right;" width="5%">Quantity</th>
					<th style="text-align:right;" width="10%">Unit Price</th>
					<th style="text-align:right;" width="10%">Price</th>
					<th style="text-align:center;" width="5%">Remove</th>
					</tr>


				</div>
			</div>
		</div>
</section><!--/slider-->

<section>
	<div class="container">

<div id="product-grid">
	<div class="txt-heading"><h1>Products</h1></div>
	<?php $__currentLoopData = $AllProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <div class="product-item">
			<form method="post" action="<?php echo e(url('listing/'.$product->product_code)); ?>">
			<div class="product-image"><img src="<?php echo e('/images/'. $product->image); ?>" style="height:80px; width:90px;"></div>
			<div class="product-tile-footer">
			<div class="product-title"><h2><?php echo e($product->product_name); ?></h2></div>
			<div class="product-price"><h2>SGD <?php echo e($product->price); ?></h2></div>
			<div class="cart-action"><input type="text" class="product-quantity" name="quantity" value="1" size="2" /><input type="submit" value="Add to Cart" class="btnAddAction" /></div>
			</div>
			</form>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>



</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontLayout.front_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopping_website\resources\views/products/listing.blade.php ENDPATH**/ ?>